Nakon konflikta, u branchu doc:
git merge main